import os


def clean_all():
    machines = open("all_machines.txt","r").readlines()
    for line in machines :
        machine = str(line.strip().split(" ")[0])
        print('clean : ' + machine)
        commande = "ssh lrose@" + machine  + " rm -rf /tmp/lrose/"
        os.system(commande)
    return()

if __name__ == '__main__':
    clean_all()


