import os
import sys

def master(file):
    os.system("python3 MASTER.py " + str(file))



if __name__ = '__main__':
    master(*sys.argv[0])
