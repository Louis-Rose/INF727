import os
import subprocess
import time
from os import listdir
import multiprocessing as mp
import numpy as np
import sys

for arg in sys.argv:
    print("arg : " + str(arg))

file_to_mapreduce = sys.argv[1]
number_of_machines = int(sys.argv[2])
nb = min(number_of_machines, 30)

print("File to MapReuce : " + str(file_to_mapreduce))



print("ETAPE 0: création de la liste des machines")
#On récupère la liste des machines à l'aide du programme mach.py, et on ne conserve que celles répondant correctement à la commande "hostname".

start_0 = time.time()

machines_list = (subprocess.check_output('python3 mach.py ' + str(nb), shell = True, text = True).split("|"))[:-1]

count = 0

machines_list_copy = machines_list[:]
machines_list_original = machines_list[:]

os.system("rm machines.txt")
f = open("/cal/homes/lrose/INF727/ETAPES_4_12/machines.txt", 'w')

for machine in machines_list_copy:
    count += 1
    print("machine : " + str(machine))
    machine_name = machine.split(" ")[0]
    test_cmd = subprocess.check_output("ssh lrose@" + str(machine_name) + " hostname", shell = True, text = True)
    print("test cmd : " + str(test_cmd))
    print("machine_name : " + str(machine_name))
    test_cmd = test_cmd.strip()
    machine_name = machine_name.strip()
    print(count)
    if not (test_cmd == machine_name):
        print("NOK")
        #On supprime cette machine de machines_list.
        machines_list_original.remove(machine)
    else:
        f.write(machine+'\n')
f.close()

print("Machines opérationelles : " + str(machines_list_original))
h = open("machines_ope.txt", 'w')
for element in machines_list_original:
    h.write(element.strip() + "\n")
h.close()

print("ETAPE 0bis : CLEAN et DEPLOY sur les machines opérationelles")


print("CLEAN")
os.system("python3 CLEAN.py " + str(nb))


print("DEPLOY")
os.system("python3 DEPLOY.py " + str(nb))


duree_etape_0 = time.time() - start_0
print("Durée étape 0 : " + str(duree_etape_0))


print('ETAPE 1 : DEPLOIEMENT DES SPLITS')
splits_start = time.time()


machines = open("machines_ope.txt",'r').readlines()
nbmachines = len(machines)
print("Nombre de machines : " + str(nbmachines))
os.system("rm -rf splits/")
os.system("mkdir -p splits/")



lines = open('/cal/homes/lrose/INF727/ETAPES_4_12/'+str(file_to_mapreduce),'r').readlines()
nblignes = len(lines)
print("Nombre de lignes : " + str(nblignes))
lpm = int(nblignes / nbmachines)+1
print("lpm : " + str(lpm))



def splitting(machine):
    count = machines.index(machine)
    machine_name = str(machine.strip().split(" ")[0]).strip()
    ip = str(machine.strip().split(" ")[1]).strip()
    print("machine : " + str(machine_name)+"  " + str(ip))
    lines_bit = []
    if count == (nbmachines-1) :
        lines_bit = lines[lpm*count:]
    else:
        lines_bit = lines[lpm*count:lpm*(count+1)]
    #Création du doc split au format .txt contenant 1 ligne de input.txt
    doc_name = "S" + str(count) + ".txt"
    doc = open("splits/" + doc_name, 'w')
    for element in lines_bit:
        if str(element).strip() == '':
            continue
        doc.write(str(element).strip() + "\n")
    doc.write(" STOP")
    doc.close()
    #Envoi de ce document dans le dossier splits d'une des machines opérationelles
    os.system("ssh lrose@" + machine_name + " rm -rf /tmp/lrose/splits_slave/")
    os.system("ssh lrose@" + machine_name + " mkdir -p /tmp/lrose/splits_slave/")
    os.system("scp ~/INF727/ETAPES_4_12/splits/" + doc_name +" lrose@" + ip +":/tmp/lrose/splits_slave/")
    return()


batches_size = min(12, nb)
if nb <= 12:
    batches_number = 1
else:
    batches_number = (nb // 12)



pool = mp.Pool(batches_size)

machines_batch = np.reshape(machines,(batches_number,batches_size))

for batch in machines_batch:    
    pool.map(splitting,batch)



splits_duration = time.time() - splits_start
print("DUREE SPLIT : " + str(splits_duration))


#Lancement de la phase de map sur les machines slaves (On a déjà DEPLOY les SLAVES en /tmp/lrose/, et MASTER vient de distribuer les splits aux slaves)



print('ENVOI DE machines_ope.txt et master.txt AUX MACHINES SLAVE (dans /tmp/)')
envoi_machines_start = time.time()

machine_file = open("machines_ope.txt", 'r')

def envoi_liste_machines(line):
    ip = str(line.strip().split(" ")[1])
    os.system("scp machines_ope.txt master.txt lrose@" + ip + ":/tmp/lrose/")
    return()

machines = machine_file.readlines()

pool = mp.Pool(batches_size)

machines_batchs = np.reshape(machines,(batches_number,batches_size))

for batch in machines_batchs :
    pool.map(envoi_liste_machines, batch)

envoi_duration = time.time() - envoi_machines_start
print("DUREE ENVOI : " +str(envoi_duration))




print('ETAPE 2 : PHASE DE MAP : SLAVE.py est appliqué aux splits sur chaque machine')
start_map = time.time()


machines = open("machines_ope.txt", "r").readlines()
#On applique le SLAVE.py aux fichiers splits, sur chaque machine distante (mode 0)


def map_fct(mach):
    mach = mach.strip().split(" ")
    machine = str(mach[0])
    ip = str(mach[1])
    #Pour chaque machine distante opérationelle, on veut appliquer SLAVE.py au document split contenu dans le dossier /tmp/lrose/splits/
    os.system("ssh lrose@" + machine + " python3 /tmp/lrose/SLAVE.py 0 /tmp/lrose/splits_slave/")
    return()


pool = mp.Pool(batches_size)

machines_batch = np.reshape(machines,(batches_number,batches_size))

for batch in machines_batch:
    pool.map(map_fct,batch)


print("MAP FINISHED")

map_duration = time.time() - start_map
print("DUREE MAP : " + str(map_duration))



print('ENVOI DE machines_ope.txt et master.txt AUX MACHINES SLAVE (dans /tmp/)')
envoi_machines_start = time.time()

machine_file = open("machines_ope.txt", 'r')

def envoi_liste_machines(line):
    ip = str(line.strip().split(" ")[1])
    os.system("scp machines_ope.txt master.txt lrose@" + ip + ":/tmp/lrose/")
    return()

machines = machine_file.readlines()

pool = mp.Pool(batches_size)

machines_batchs = np.reshape(machines,(batches_number,batches_size))

for batch in machines_batchs :
    pool.map(envoi_liste_machines, batch)

envoi_duration = time.time() - envoi_machines_start
print("DUREE ENVOI : " +str(envoi_duration))


print('LANCEMENT DE LA PHASE DE SHUFFLE : ON UTILISE SLAVE.py avec function_mode = 1')
shuffle_start = time.time()


#On commence par créer les dossiers shuffles et shufflesreceived sur l'ensemble des machines distantes, avec un pool à part, afin de s'assurer que les dossiers sont bien créés avant d'appliquer SLAVE.py 1.


machines = open("machines_ope.txt", 'r').readlines()

def directory_creation(line):
    machine = line.strip().split(" ")[0].strip()
    ip = line.strip().split(" ")[1].strip()
    print(" ip : " + str(ip))
    os.system("ssh lrose@" + str(machine) + " rm -rf  /tmp/lrose/shuffles/ /tmp/lrose/shufflesreceived/")
    os.system("ssh lrose@" + str(machine) + " mkdir -p /tmp/lrose/shuffles/ /tmp/lrose/shufflesreceived/")
    return()

print("DIRECTORIES CREATION")
pool = mp.Pool(batches_size)
batches = np.reshape(machines, (batches_number,batches_size))
for batch in batches :
    print("batch : " + str(batch))
    pool.map(directory_creation, batch)
    


#Sur chaque machine distante, on applique SLAVE.py 1 aux maps. SLAVE.py prend en argument 1 document UMx.txt.



def shuffle(line):
    line = line.strip().split(" ")
    machine = str(line[0])
    ip = str(line[1])
    print( 'machine : ' + str(machine))
    print( 'ip : ' + str(ip))
    #Sur chaque machine distante, on applique SLAVE.py 1 à chaque fichier présent dans /tmp/lrose/maps/
    map_files  = subprocess.check_output('ssh lrose@'+machine+ ' ls /tmp/lrose/maps/', shell = True, text = True)
    map_files = map_files.strip().split(" ")
    for file in map_files :
        print("On applique SLAVE 1 à :" + str(file))
        cmd = 'ssh lrose@'+str(machine)+ ' python3 /tmp/lrose/SLAVE.py 1 /tmp/lrose/maps/' +str(file)
        os.system(cmd)
    return()




pool = mp.Pool(batches_size)
machines_batches = np.reshape(machines,(batches_number,batches_size))

for batch in machines_batches:
    pool.map(shuffle,batch)


print("SHUFFLE FINISHED")

shuffle_duration = time.time() - shuffle_start
print("DUREE DU SHUFFLE : " + str(shuffle_duration))

os.system("rm -rf /cal/homes/lrose/INF727/ETAPES_4_12/all_reduces/")
os.system("mkdir -p /cal/homes/lrose/INF727/ETAPES_4_12/all_reduces/")

reduce_start = time.time()
print("PHASE DE REDUCE")


machines = open("machines_ope.txt", 'r').readlines()

#Sur chacune des machines Slaves, on va appliquer SLAVE.py 2 au dossier /tmp/lrose/shufflesreceived/

#On commence par créer le dossier reduces/ sur toutes les machines distantes, avec un pool à part, afin de s'assurer que les dossiers sont bien créés avant de travailler dessus.

def reduces_mkdir(line):
    machine = str(line.split(" ")[0])
    os.system("ssh lrose@" + str(machine) + " mkdir -p /tmp/lrose/reduces/")
    return()

print("REDUCES directories CREATION.")
pool = mp.Pool(batches_size)
machines_batches = np.reshape(machines,(batches_number,batches_size))
for batch in machines_batches:
    print("batch : " + str(batch))
    pool.map(reduces_mkdir,batch)


#Maintenant, on créé un autre pool pour, sur chaque machine distante, appliquer SLAVE.py 2 au dossier shufflesreceived/.

def reduce_fct(line):
    machine = str(line.split(" ")[0])
    print(machine)
    cmd = "ssh lrose@" + str(machine) + "  python3 /tmp/lrose/SLAVE.py 2 /tmp/lrose/shufflesreceived/"
    os.system(cmd)
    return()

#On lance l'instruction de Reduce sur les slaves en parallèle.
pool = mp.Pool(batches_size)
machines_batches = np.reshape(machines,(batches_number,batches_size))
for batch in machines_batches:
    pool.map(reduce_fct,batch)

print("REDUCE FINISHED")
reduce_duration = time.time() - reduce_start


print("CONCATENATION STEP")
concatenation_start = time.time()


os.system("rm -rf /cal/homes/lrose/INF727/ETAPES_4_12/results.txt")
f = open("/cal/homes/lrose/INF727/ETAPES_4_12/results.txt",'a+')
reduces = os.listdir("/cal/homes/lrose/INF727/ETAPES_4_12/all_reduces/")
        
for file in reduces :
    print("file : " + str(file))
    file = open("/cal/homes/lrose/INF727/ETAPES_4_12/all_reduces/"+ (str(file).strip()), 'r')
    lines = file.readlines()
    for line in lines :
        if line.strip() != '':
            print("ligne : " + str(line))
            f.write(line+"\n")
f.close()
        
'''
results = open("/cal/homes/lrose/INF727/ETAPES_4_12/results.txt", 'w+')

reduce_files = os.listdir("/cal/homes/lrose/INF727/ETAPES_4_12/all_reduces/reduces/")

for file_ in reduce_files :
    file_content = open("/cal/homes/lrose/INF727/ETAPES_4_12/all_reduces/reduces/" + str(file_),'r')
    lines = file_content.readlines()
    print("CONTENU FICHIER")
    os.system ("cat /cal/homes/lrose/INF727/ETAPES_4_12/all_reduces/reduces/" + str(file_))
    word = str(lines[0].split(" ")[0]).strip()
    count = 0
    for line in lines:
        if line.strip() == '':
            continue
        count += int(line.split(" ")[1])
    line_to_write = word + " " +  str(count)
    results.write(line_to_write + "\n")
    
results.close()

'''


concatenation_duration = time.time() - concatenation_start


print("DUREE ETAPE 0 : " + str(duree_etape_0))
print("DUREE SPLIT : " + str(round(splits_duration,2)))
print("DUREE MAP : " + str(round(map_duration,2)))
print("DUREE ENVOI : " +str(round(envoi_duration,2)))
print("DUREE DU SHUFFLE : " + str(round(shuffle_duration,2)))
print("DUREE REDUCE : " +str(round(reduce_duration,2)))
print("DUREE CONCATENATION : " + str(round(concatenation_duration,2)))

print("DUREE TOTALE : " + str(round((duree_etape_0 + splits_duration + map_duration +  envoi_duration + shuffle_duration + reduce_duration + concatenation_duration),2)))
