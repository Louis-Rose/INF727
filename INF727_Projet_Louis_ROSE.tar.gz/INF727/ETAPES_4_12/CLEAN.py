import os
import sys
import multiprocessing as mp
import numpy as np

import sys

nb = int(sys.argv[1])
print("nb :" + str(nb))

print("Nombre de CPUs : " +str(mp.cpu_count()))
n_core = mp.cpu_count()


batch_size = min(nb, 12)
batches_nb = (nb//12)+1


def clean(line):
    machine = str(line.strip().split(" ")[0])
    print('clean : ' + machine)
    commande = "ssh lrose@" + machine  + " rm -rf /tmp/lrose/"
    os.system(commande)
    return()


machines = open("machines.txt","r").readlines()


pool = mp.Pool(batch_size)

mach = np.reshape(machines,(batches_nb,batch_size))

for mach_batch in mach :
    pool.map(clean,mach_batch)

