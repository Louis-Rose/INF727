import sys

machine_ = "tp-1a226-"
ip_ = "137.194.140."


list_of_machines = ""

number_of_machines = int(sys.argv[1])
nb = min(number_of_machines, 30)

value_machine =4
value_ip = 133
for i in range(nb):
    if i < 6 and machine_[-1] != "0":
        machine_ = machine_ + "0"
    if i == 6 and machine_[-1] == "0":
        machine_ = machine_[:-1]
    list_of_machines += (str(machine_) +str(value_machine + i))
    list_of_machines += " "
    list_of_machines += (str(ip_)+str(value_ip + i))
    list_of_machines += "|"

print(list_of_machines)
