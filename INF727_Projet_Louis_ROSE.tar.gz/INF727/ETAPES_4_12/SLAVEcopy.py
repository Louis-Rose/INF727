import sys
import time
import os
import subprocess
import multiprocessing as mp
import numpy as np

master = open("/tmp/lrose/master.txt").readlines()[0]

master_ip = str(master.split(" ")[0])



def slave(function_mode, filepath):
    
    function_mode = int(function_mode)
    
    if function_mode == 0:
        '''PHASE DE MAP : Cette fonction créé un dossier maps, et un fichier UMx.txt, qui map le fichier split dont le path est passé en argument.'''
        os.system("rm -rf /tmp/lrose/maps/")
        os.system("mkdir -p /tmp/lrose/maps/")
        splits = os.listdir("/tmp/lrose/splits_slave/")
        for split in splits:
            filenumber = str(split)[1:-4]
            result_file_name = "UM" + str(filenumber) + ".txt"
            result_file = open("/tmp/lrose/maps/" + result_file_name, "w")
            arg_file = open(filepath+str(split), 'r')
            for line in arg_file:
                line = line.strip().split(" ")
                for word in line :
                    if word.strip() == "":
                        continue
                    if word[-1] == "." or word[-1] == "," or word[-1] == ":":
                        word = word[:-1]
                    result_file.write(word + " 1\n")
    
        return()


    if function_mode == 2:
        #Phase de reduce. On créé un dossier reduces, on itère sur le dossier shufflesreceived, on créé les fichiers hash.txt. On somme les nombres trouvés
        shuffles_received = os.listdir(filepath)
        hash_word_number = [[],[],[]]
        for file in shuffles_received:
            os.system("cat /tmp/lrose/shufflesreceived/" +str(file))
            hash_ = file.split("-")[0]
            f = open(("/tmp/lrose/shufflesreceived/" + str(file)),'r')
            for line in f:
                if line.strip() == '':
                    continue

                hash_word_number[0].append(hash_)
                line = line.split(" ")
                hash_word_number[1].append(line[0])
                hash_word_number[2].append(line[1].strip())
            print("NEXT FILE")

        test_list = []
        count = 0
        for word in hash_word_number[1]:
            element = (str(hash_word_number[0][count]) + " " + str(hash_word_number[1][count]) + " " + str(hash_word_number[2][count])).split(" ")
            test_list.append(element)
            count += 1 
        
    
        hash_word_number = sorted (test_list, key = lambda x : x[0] )

        n = len(hash_word_number)
        
        total = 0
        count = 1
        for i in range(n-1):
            count += 1
            print("count: " + str(count))
            print("n : " + str(n))
            word_1 = hash_word_number[i][1]
            word_2 = hash_word_number[i+1][1]

            hash_1 = hash_word_number[i][0]
            hash_2 = hash_word_number[i+1][0]
            
            number_1 = hash_word_number[i][2]
            number_2 = hash_word_number[i+1][2]
                
            total += int(number_1)
            

            if (hash_1 == hash_2):
                if (count == n):
                    total += int(number_2)
                    filename = str(hash_1) + ".txt"
                    line = str(word_1) + " " + str(total)
                    print("line : " + str(line))
                    print("line.strip() : " + str(line.strip()))
                    e = open("/tmp/lrose/reduces/" + str(filename), 'w')
                    e.write(line.strip())
                    print("LAST WORD : Just printed " + str(line) + " in " + str(filename))
                    total = 0
                

                else :
                    continue
            else:
                filename = str(hash_1) + ".txt"
                line = str(word_1) + " " + str(total)
                print(filename, line)
                f = open("/tmp/lrose/reduces/" + str(filename),'w')
                f.write(line.strip())
                print("!= HASH : Just printed " + str(line) + " in " + str(filename))
                total = 0
                
                if (count == n):
                    filename = str(hash_2) + ".txt"
                    line = str(word_2) + " " + str(number_2)
                    g = open("/tmp/lrose/reduces/" + str(filename), 'w+')
                    g.write(last_line.strip())
                    print("Just printed " + str(line) + " in " + str(filename))
                    total = 0
        
        
        os.system("scp -r /tmp/lrose/reduces lrose@" +str(master_ip) + ":/cal/homes/lrose/INF727/ETAPES_4_12/all_reduces/")

       
    






    if function_mode == 1:
        
        #préparation au SHUFFLE : créé le dossier shuffles, calcul des hashs création des fichiers hash_hostname.txt dans le dossier shuffles (Tout sur le SLAVE local, sur chacun des SLAVES)
        machine_name = str(subprocess.check_output('hostname', text = True)).strip()
        print('Machine name : ' + machine_name)
        #os.system("mkdir -p /tmp/lrose/shuffles/")
        filenumber = filepath[-5]
        arg_file = open(filepath, 'r')
        for line in arg_file : 
            word = str(line.strip().split(" ")[0])
            #Calcul du Hash du word
            hash_value, i = 0,0
            n = len(word)
            for letter in word:
                hash_value += ord(letter)*(31**(n-1-i))
                i += 1
            print("Hash of " + word + " : " + str(hash_value))
            
            #Création/complétion du fichier hash-hostname.txt
            result_file_name = str(hash_value) + "-" + machine_name + ".txt"
            result_file = open("/tmp/lrose/shuffles/" + result_file_name,"a+")
            result_file.write(line +"\n")
        
        machines = open('/tmp/lrose/machines_ope.txt', 'r')
        nbMachines = 0
        for line in machines :
            nbMachines += 1
        print('Nombre de machines : ' + str(nbMachines))
        
        shuffles_to_send = os.listdir('/tmp/lrose/shuffles/')
        for file in shuffles_to_send :
            # Une itération par fichier
            print("shuffle to send : " +  str(file))
            os.system("cat /tmp/lrose/shuffles/" + str(file))
            splitted_file = file.split("-")
            hash_value = int(splitted_file[0])
            machine_locale = splitted_file[1]+'-'+splitted_file[2] +'-'+ (splitted_file[3]).split('.')[0] 
            numeroMachine = hash_value % nbMachines
            print('numeroMachine :' +str(numeroMachine))
            machines = open('/tmp/lrose/machines_ope.txt', 'r')
            machine_to_send_with_ip = (machines.readlines())[numeroMachine]
            machine_to_send = machine_to_send_with_ip.split(" ")[0]
            ip = machine_to_send_with_ip.split(" ")[1].strip()
            print('machine_to_send : ' +str(machine_to_send))
            print('ip : ' + str(ip))
            #mkdir_cmd = "ssh lrose@" + str(machine_to_send) +" mkdir -p /tmp/lrose/shufflesreceived/"
            file = str(file)
            print('file : ' + file)
            copy_cmd = "scp /tmp/lrose/shuffles/" + file + " lrose@" + str(ip) + ":/tmp/lrose/shufflesreceived/"
            os.system(copy_cmd)
        return()



if __name__ == '__main__' :
    #Maps the command line arguments to function arguments
    slave(*sys.argv[1:])
