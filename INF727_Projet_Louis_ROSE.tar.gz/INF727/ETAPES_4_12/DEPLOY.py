import os
import sys
import subprocess
import multiprocessing as mp
import numpy as np

nb = int(sys.argv[1])
print("nb : " + str(nb))

ip_master = subprocess.check_output("hostname -i", shell = True, text = True)
ip_master = ip_master.strip()
print("master : " + str(ip_master))

machines_lines = open("machines.txt", "r").readlines()

def deploy(line):
    machine = str(line.strip().split(" ")[0])
    ip = line.strip().split(" ")[1]
    print("deploy : " + machine)
    os.system("ssh lrose@" + machine + " mkdir -p /tmp/lrose/")
    scp_cmd = "scp lrose@" +str(ip_master) + ":~/INF727/ETAPES_4_12/SLAVE.py lrose@" + ip + ":/tmp/lrose/"
    os.system(scp_cmd)
    print('SLAVE copié sur la machine distante.')

batch_size = min(12, nb)

if nb <= 12:
    batches_number = 1
else:
    batches_number = (nb // 12)

pool = mp.Pool(batch_size)

mach_batch = np.reshape(machines_lines,(batch_size,batches_number))

for batch in mach_batch :
    pool.map(deploy,batch)


'''

processes = []
for i in range(10):
    p = mp.Process(target = deploy, args = (machines_lines[i],))
    processes.append(p)
for i in range(10):
    processes[i].start()
    print(os.getpid())
for i in range(10):
    processes[i].join()

processes = []
for i in range(10,20):
    p = mp.Process(target = deploy, args = (machines_lines[i],))
    processes.append(p)
for i in range(10):
    processes[i].start()
    print(os.getpid())
for i in range(10):
    processes[i].join()

processes = []
for i in range(20,30):
    p = mp.Process(target = deploy, args = (machines_lines[i],))
    processes.append(p)
for i in range(10):
    processes[i].start()
    print(os.getpid())
for i in range(10):
    processes[i].join()

'''
